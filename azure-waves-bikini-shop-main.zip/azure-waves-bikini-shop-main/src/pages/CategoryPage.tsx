
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { getAllProducts, Product } from "@/data/products";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Star, ShoppingBag } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

export default function CategoryPage() {
  const { category } = useParams<{ category: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch
    const loadProducts = () => {
      setLoading(true);
      try {
        const result = getAllProducts(currentPage, 12);
        // In a real app, we'd filter by category here
        setProducts(result.products);
        setTotalPages(result.totalPages);
      } catch (error) {
        console.error("Error loading products:", error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, [category, currentPage]);

  const formatPrice = (price: number) => {
    return `₹${price.toLocaleString('en-IN')}`;
  };

  const getCategoryTitle = () => {
    if (!category) return "All Products";
    return category.charAt(0).toUpperCase() + category.slice(1);
  };

  return (
    <>
      <Navbar />
      <main>
        {/* Page Header */}
        <section className="bg-gray-50 py-8">
          <div className="container mx-auto px-4">
            {/* Breadcrumbs */}
            <nav className="flex text-sm mb-4">
              <a href="/" className="text-gray-500 hover:text-ocean">Home</a>
              <span className="mx-2 text-gray-400">/</span>
              <span className="text-gray-700 capitalize">{getCategoryTitle()}</span>
            </nav>
            
            <h1 className="text-3xl font-bold text-gray-900">{getCategoryTitle()}</h1>
          </div>
        </section>
        
        {/* Category Content */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row">
              {/* Filters - for desktop */}
              <div className="hidden lg:block w-64 mr-8">
                <div className="sticky top-8">
                  <h2 className="text-lg font-medium text-gray-900 mb-4">Filters</h2>
                  
                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Price Range</h3>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded text-ocean focus:ring-ocean mr-2" />
                        <span className="text-sm text-gray-700">Under ₹1000</span>
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded text-ocean focus:ring-ocean mr-2" />
                        <span className="text-sm text-gray-700">₹1000 - ₹2000</span>
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded text-ocean focus:ring-ocean mr-2" />
                        <span className="text-sm text-gray-700">₹2000 - ₹3000</span>
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded text-ocean focus:ring-ocean mr-2" />
                        <span className="text-sm text-gray-700">Over ₹3000</span>
                      </label>
                    </div>
                  </div>
                  
                  {/* Size */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Size</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {["XS", "S", "M", "L", "XL"].map((size) => (
                        <button
                          key={size}
                          className="border border-gray-300 rounded px-2 py-1 text-sm text-gray-700 hover:border-ocean hover:text-ocean"
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  {/* Color */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Color</h3>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { name: "Black", code: "#171717" },
                        { name: "White", code: "#ffffff" },
                        { name: "Blue", code: "#0ea5e9" },
                        { name: "Red", code: "#ef4444" },
                        { name: "Green", code: "#10b981" },
                        { name: "Pink", code: "#ec4899" },
                      ].map((color) => (
                        <button
                          key={color.name}
                          className="w-8 h-8 rounded-full border border-gray-300 hover:border-ocean"
                          style={{ backgroundColor: color.code }}
                          title={color.name}
                        />
                      ))}
                    </div>
                  </div>
                  
                  {/* Style */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Style</h3>
                    <div className="space-y-2">
                      {["Bikini", "One-Piece", "Tankini", "Bandeau", "Triangle", "High-Waist"].map((style) => (
                        <label className="flex items-center" key={style}>
                          <input type="checkbox" className="rounded text-ocean focus:ring-ocean mr-2" />
                          <span className="text-sm text-gray-700">{style}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <Button className="w-full bg-ocean hover:bg-ocean-dark">Apply Filters</Button>
                </div>
              </div>
              
              {/* Product Grid */}
              <div className="flex-1">
                {/* Sort and Filter Controls */}
                <div className="flex justify-between items-center mb-6">
                  <div className="text-sm text-gray-700">
                    Showing <span className="font-medium">{products.length}</span> results
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-700">Sort by:</span>
                    <select className="text-sm border border-gray-300 rounded-md p-1 bg-white">
                      <option>Featured</option>
                      <option>Price: Low to High</option>
                      <option>Price: High to Low</option>
                      <option>Newest</option>
                      <option>Best Selling</option>
                    </select>
                  </div>
                </div>
                
                {loading ? (
                  <div className="flex justify-center py-16">
                    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-ocean"></div>
                  </div>
                ) : (
                  <>
                    {/* Product Grid */}
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
                      {products.map(product => (
                        <div key={product.id} className="group">
                          <div className="relative mb-4 overflow-hidden rounded-lg bg-gray-100 aspect-[3/4]">
                            <Link to={`/product/${product.id}`}>
                              <img 
                                src={product.variants[0].images[0]} 
                                alt={product.name} 
                                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                              />
                            </Link>
                            
                            {product.salePrice && (
                              <div className="absolute top-2 left-2 bg-coral text-white text-xs font-bold px-2 py-1 rounded">
                                SALE
                              </div>
                            )}
                            
                            <div className="absolute inset-x-0 bottom-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              <Button 
                                className="w-full rounded-none bg-ocean hover:bg-ocean-dark text-white flex items-center justify-center py-2"
                                size="sm"
                              >
                                <ShoppingBag className="w-4 h-4 mr-2" />
                                Quick Add
                              </Button>
                            </div>
                          </div>
                          
                          <Link to={`/product/${product.id}`} className="block mb-1">
                            <h3 className="text-sm font-medium text-gray-900 hover:text-ocean transition-colors line-clamp-1">
                              {product.name}
                            </h3>
                          </Link>
                          
                          <div className="flex items-center mb-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={cn(
                                  "w-3 h-3",
                                  i < Math.floor(product.avgRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                )}
                              />
                            ))}
                            <span className="ml-1 text-xs text-gray-500">
                              ({product.totalReviews})
                            </span>
                          </div>
                          
                          <div className="flex items-center">
                            {product.salePrice ? (
                              <>
                                <span className="font-medium text-coral">{formatPrice(product.salePrice)}</span>
                                <span className="ml-2 text-sm text-gray-500 line-through">{formatPrice(product.price)}</span>
                              </>
                            ) : (
                              <span className="font-medium text-gray-900">{formatPrice(product.price)}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    {/* Pagination */}
                    {totalPages > 1 && (
                      <div className="flex justify-center mt-12">
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline"
                            disabled={currentPage === 1}
                            onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
                          >
                            Previous
                          </Button>
                          
                          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                            <Button
                              key={page}
                              variant={page === currentPage ? "default" : "outline"}
                              className={page === currentPage ? "bg-ocean hover:bg-ocean-dark" : ""}
                              onClick={() => setCurrentPage(page)}
                            >
                              {page}
                            </Button>
                          ))}
                          
                          <Button 
                            variant="outline"
                            disabled={currentPage === totalPages}
                            onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
                          >
                            Next
                          </Button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
