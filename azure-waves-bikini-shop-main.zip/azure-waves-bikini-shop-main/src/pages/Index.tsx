
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getAllProducts, Product, getProductsByTag } from '@/data/products';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Star, ShoppingBag, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Index() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [newArrivals, setNewArrivals] = useState<Product[]>([]);
  const [bestsellers, setBestsellers] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch
    const loadProducts = () => {
      setLoading(true);
      try {
        // Get initial products
        const { products } = getAllProducts(1, 8);
        setFeaturedProducts(products.slice(0, 4));
        
        // Get products by tags
        setNewArrivals(getProductsByTag('new', 8));
        setBestsellers(getProductsByTag('bestseller', 4));
      } catch (error) {
        console.error("Error loading products:", error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  const formatPrice = (price: number) => {
    return `₹${price.toLocaleString('en-IN')}`;
  };

  return (
    <>
      <Navbar />
      <main>
        {/* Hero Section */}
        <section className="relative bg-gray-900 h-[600px] flex items-center">
          <div className="absolute inset-0 overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1565731761535-4d58a948f7ed?q=80&w=2070&auto=format&fit=crop"
              alt="Woman in swimwear on beach"
              className="w-full h-full object-cover opacity-70"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent"></div>
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-md text-white">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Summer Collection 2025</h1>
              <p className="text-lg mb-8">Discover our stunning new swimwear collection designed for comfort, style, and confidence.</p>
              <div className="flex space-x-4">
                <Button className="bg-ocean hover:bg-ocean-dark text-white">
                  Shop Collection
                </Button>
                <Button variant="outline" className="text-white border-white hover:bg-white/10">
                  View Lookbook
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Shop By Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                {
                  name: "Bikinis",
                  image: "https://images.unsplash.com/photo-1596005554384-d293674c91d7?q=80&w=1287&auto=format&fit=crop",
                  link: "/category/bikini"
                },
                {
                  name: "One-Piece",
                  image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=1287&auto=format&fit=crop",
                  link: "/category/onepiece"
                },
                {
                  name: "Separates",
                  image: "https://images.unsplash.com/photo-1529171488825-cc6c4ec2590c?q=80&w=1287&auto=format&fit=crop",
                  link: "/category/separates"
                },
                {
                  name: "Accessories",
                  image: "https://images.unsplash.com/photo-1564482596500-d09089fbb403?q=80&w=774&auto=format&fit=crop",
                  link: "/category/accessories"
                }
              ].map((category, index) => (
                <Link 
                  key={index}
                  to={category.link}
                  className="group relative overflow-hidden rounded-lg aspect-square"
                >
                  <img 
                    src={category.image} 
                    alt={category.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors duration-300"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-white text-xl font-semibold px-4 py-2 bg-black/40 rounded">
                      {category.name}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* New Arrivals Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold">New Arrivals</h2>
              <Link 
                to="/new-arrivals" 
                className="text-ocean hover:text-ocean-dark flex items-center font-medium"
              >
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-ocean"></div>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {newArrivals.map(product => (
                  <div key={product.id} className="group">
                    <div className="relative mb-4 overflow-hidden rounded-lg bg-gray-100 aspect-[3/4]">
                      <Link to={`/product/${product.id}`}>
                        <img 
                          src={product.variants[0].images[0]} 
                          alt={product.name} 
                          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                        />
                      </Link>
                      
                      {product.salePrice && (
                        <div className="absolute top-2 left-2 bg-coral text-white text-xs font-bold px-2 py-1 rounded">
                          SALE
                        </div>
                      )}
                      
                      <div className="absolute inset-x-0 bottom-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <Button 
                          className="w-full rounded-none bg-ocean hover:bg-ocean-dark text-white flex items-center justify-center py-2"
                          size="sm"
                        >
                          <ShoppingBag className="w-4 h-4 mr-2" />
                          Quick Add
                        </Button>
                      </div>
                    </div>
                    
                    <Link to={`/product/${product.id}`} className="block mb-1">
                      <h3 className="text-sm font-medium text-gray-900 hover:text-ocean transition-colors line-clamp-1">
                        {product.name}
                      </h3>
                    </Link>
                    
                    <div className="flex items-center mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={cn(
                            "w-3 h-3",
                            i < Math.floor(product.avgRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                          )}
                        />
                      ))}
                      <span className="ml-1 text-xs text-gray-500">
                        ({product.totalReviews})
                      </span>
                    </div>
                    
                    <div className="flex items-center">
                      {product.salePrice ? (
                        <>
                          <span className="font-medium text-coral">{formatPrice(product.salePrice)}</span>
                          <span className="ml-2 text-sm text-gray-500 line-through">{formatPrice(product.price)}</span>
                        </>
                      ) : (
                        <span className="font-medium text-gray-900">{formatPrice(product.price)}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Featured Banner */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="relative overflow-hidden rounded-xl h-[400px]">
              <img 
                src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070&auto=format&fit=crop" 
                alt="Summer collection" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-ocean/80 to-transparent flex items-center">
                <div className="ml-12 max-w-md text-white">
                  <span className="text-xl mb-2 inline-block border border-white/50 px-3 py-1 rounded-full">Limited Time</span>
                  <h2 className="text-4xl font-bold mb-4">Summer Sale<br />Up to 50% Off</h2>
                  <p className="mb-6">Refresh your summer wardrobe with our stunning collection at incredible prices. Limited stock available.</p>
                  <Button className="bg-white text-ocean hover:bg-gray-100">
                    Shop the Sale
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Bestsellers Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold">Bestsellers</h2>
              <Link 
                to="/bestsellers" 
                className="text-ocean hover:text-ocean-dark flex items-center font-medium"
              >
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-ocean"></div>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {bestsellers.map(product => (
                  <div key={product.id} className="group">
                    <div className="relative mb-4 overflow-hidden rounded-lg bg-gray-100 aspect-[3/4]">
                      <Link to={`/product/${product.id}`}>
                        <img 
                          src={product.variants[0].images[0]} 
                          alt={product.name} 
                          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                        />
                      </Link>
                      
                      {product.salePrice && (
                        <div className="absolute top-2 left-2 bg-coral text-white text-xs font-bold px-2 py-1 rounded">
                          SALE
                        </div>
                      )}
                      
                      <div className="absolute inset-x-0 bottom-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <Button 
                          className="w-full rounded-none bg-ocean hover:bg-ocean-dark text-white flex items-center justify-center py-2"
                          size="sm"
                        >
                          <ShoppingBag className="w-4 h-4 mr-2" />
                          Quick Add
                        </Button>
                      </div>
                    </div>
                    
                    <Link to={`/product/${product.id}`} className="block mb-1">
                      <h3 className="text-sm font-medium text-gray-900 hover:text-ocean transition-colors line-clamp-1">
                        {product.name}
                      </h3>
                    </Link>
                    
                    <div className="flex items-center mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={cn(
                            "w-3 h-3",
                            i < Math.floor(product.avgRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                          )}
                        />
                      ))}
                      <span className="ml-1 text-xs text-gray-500">
                        ({product.totalReviews})
                      </span>
                    </div>
                    
                    <div className="flex items-center">
                      {product.salePrice ? (
                        <>
                          <span className="font-medium text-coral">{formatPrice(product.salePrice)}</span>
                          <span className="ml-2 text-sm text-gray-500 line-through">{formatPrice(product.price)}</span>
                        </>
                      ) : (
                        <span className="font-medium text-gray-900">{formatPrice(product.price)}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mb-4 text-ocean" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                    </svg>
                  ),
                  title: "Free Shipping",
                  description: "On orders above ₹2999"
                },
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mb-4 text-ocean" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  ),
                  title: "Secure Payments",
                  description: "100% secure checkout"
                },
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mb-4 text-ocean" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  ),
                  title: "Easy Returns",
                  description: "30-day return policy"
                },
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mb-4 text-ocean" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  ),
                  title: "Customer Support",
                  description: "24/7 dedicated support"
                }
              ].map((feature, index) => (
                <div key={index} className="text-center p-6 border border-gray-100 rounded-lg shadow-sm">
                  <div className="flex justify-center">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Instagram Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-3">Follow Us on Instagram</h2>
            <p className="text-center text-gray-600 mb-8">@AzureWavesBikini</p>
            
            <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
              {[
                "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=1287&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1596005554384-d293674c91d7?q=80&w=1287&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1564482596500-d09089fbb403?q=80&w=774&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1529171488825-cc6c4ec2590c?q=80&w=1287&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?q=80&w=1528&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1527180718958-1721e2518786?q=80&w=1528&auto=format&fit=crop"
              ].map((image, index) => (
                <a 
                  key={index}
                  href="#"
                  className="group relative aspect-square overflow-hidden"
                >
                  <img 
                    src={image} 
                    alt={`Instagram post ${index + 1}`} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="py-20 bg-ocean text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-3">Join Our Newsletter</h2>
            <p className="max-w-xl mx-auto mb-8">Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
            <form className="max-w-md mx-auto flex">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-1 min-w-0 px-4 py-3 text-gray-900 bg-white border-0 rounded-l-md focus:outline-none focus:ring-2 focus:ring-white"
                required
              />
              <button
                type="submit"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-r-md text-ocean bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-white"
              >
                Subscribe
              </button>
            </form>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
