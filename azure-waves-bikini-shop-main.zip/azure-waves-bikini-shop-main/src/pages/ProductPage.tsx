
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getProductById, getRelatedProducts, Product, ProductVariant } from "@/data/products";
import { ProductGallery } from "@/components/ProductGallery";
import { ProductDetails } from "@/components/ProductDetails";
import { ReviewSection } from "@/components/ReviewSection";
import { RelatedProducts } from "@/components/RelatedProducts";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [activeVariant, setActiveVariant] = useState<ProductVariant | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch
    const loadProduct = () => {
      setLoading(true);
      try {
        if (!id) {
          navigate('/');
          return;
        }

        const foundProduct = getProductById(id);
        if (!foundProduct) {
          navigate('/404');
          return;
        }

        setProduct(foundProduct);
        setActiveVariant(foundProduct.variants[0]);
        setRelatedProducts(getRelatedProducts(foundProduct.id));
      } catch (error) {
        console.error("Error loading product:", error);
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [id, navigate]);

  const handleVariantChange = (variant: ProductVariant) => {
    setActiveVariant(variant);
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-ocean"></div>
      </div>
    );
  }

  if (!product || !activeVariant) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
        <p className="text-gray-600 mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <button
          onClick={() => navigate('/')}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-ocean hover:bg-ocean-dark"
        >
          Return to Shop
        </button>
      </div>
    );
  }

  return (
    <>
      <Navbar />
      <main>
        {/* Breadcrumbs */}
        <div className="container mx-auto px-4 py-4">
          <nav className="flex text-sm">
            <a href="/" className="text-gray-500 hover:text-ocean">Home</a>
            <span className="mx-2 text-gray-400">/</span>
            <a href={`/category/${product.category[0]}`} className="text-gray-500 hover:text-ocean capitalize">
              {product.category[0]}
            </a>
            <span className="mx-2 text-gray-400">/</span>
            <span className="text-gray-700">{product.name}</span>
          </nav>
        </div>

        {/* Product Section */}
        <section className="container mx-auto px-4 py-8">
          <div className="flex flex-col lg:flex-row -mx-4">
            <ProductGallery 
              variants={product.variants} 
              activeVariant={activeVariant} 
            />
            <ProductDetails 
              product={product} 
              activeVariant={activeVariant} 
              onVariantChange={handleVariantChange} 
            />
          </div>
        </section>

        {/* Reviews Section */}
        <section className="container mx-auto px-4">
          <ReviewSection product={product} />
        </section>

        {/* Related Products */}
        <section className="container mx-auto px-4">
          <RelatedProducts products={relatedProducts} />
        </section>
      </main>
      <Footer />
    </>
  );
}
