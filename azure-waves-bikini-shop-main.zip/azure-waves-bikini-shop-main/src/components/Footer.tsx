
import { Link } from 'react-router-dom';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-50 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Azure Waves</h3>
            <p className="text-gray-600 mb-4">Exquisite swimwear that combines elegance, comfort, and beauty for the modern woman.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-ocean" aria-label="Facebook">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a href="#" className="text-gray-500 hover:text-ocean" aria-label="Instagram">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </a>
              <a href="#" className="text-gray-500 hover:text-ocean" aria-label="Twitter">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </a>
              <a href="#" className="text-gray-500 hover:text-ocean" aria-label="Pinterest">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Shop</h3>
            <ul className="space-y-2">
              <li><Link to="/category/bikini" className="text-gray-600 hover:text-ocean">Bikinis</Link></li>
              <li><Link to="/category/onepiece" className="text-gray-600 hover:text-ocean">One-Piece</Link></li>
              <li><Link to="/category/separates" className="text-gray-600 hover:text-ocean">Separates</Link></li>
              <li><Link to="/category/accessories" className="text-gray-600 hover:text-ocean">Accessories</Link></li>
              <li><Link to="/new-arrivals" className="text-gray-600 hover:text-ocean">New Arrivals</Link></li>
              <li><Link to="/sale" className="text-gray-600 hover:text-ocean">Sale</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link to="/contact" className="text-gray-600 hover:text-ocean">Contact Us</Link></li>
              <li><Link to="/shipping" className="text-gray-600 hover:text-ocean">Shipping & Delivery</Link></li>
              <li><Link to="/returns" className="text-gray-600 hover:text-ocean">Returns & Exchanges</Link></li>
              <li><Link to="/faqs" className="text-gray-600 hover:text-ocean">FAQs</Link></li>
              <li><Link to="/size-guide" className="text-gray-600 hover:text-ocean">Size Guide</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Join Our Newsletter</h3>
            <p className="text-gray-600 mb-4">Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
            <form className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 min-w-0 px-4 py-2 text-sm text-gray-900 bg-white border border-gray-300 rounded-l-md focus:outline-none focus:ring-1 focus:ring-ocean"
                required
              />
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-r-md text-white bg-ocean hover:bg-ocean-dark focus:outline-none"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500 mb-4 md:mb-0">
              &copy; {currentYear} Azure Waves. All rights reserved.
            </p>
            <div className="flex flex-wrap justify-center space-x-4">
              <Link to="/privacy-policy" className="text-sm text-gray-500 hover:text-ocean mb-2 md:mb-0">Privacy Policy</Link>
              <Link to="/terms-of-service" className="text-sm text-gray-500 hover:text-ocean mb-2 md:mb-0">Terms of Service</Link>
              <Link to="/accessibility" className="text-sm text-gray-500 hover:text-ocean mb-2 md:mb-0">Accessibility</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
