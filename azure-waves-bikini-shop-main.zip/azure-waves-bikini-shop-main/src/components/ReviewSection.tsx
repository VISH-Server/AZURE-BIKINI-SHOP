
import { useState } from 'react';
import { Product, Review } from '@/data/products';
import { Button } from '@/components/ui/button';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ReviewSectionProps {
  product: Product;
}

export function ReviewSection({ product }: ReviewSectionProps) {
  const [expandedReviews, setExpandedReviews] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'newest' | 'helpful' | 'highest' | 'lowest'>('helpful');

  const toggleReviewExpansion = (reviewId: string) => {
    setExpandedReviews(prev => 
      prev.includes(reviewId) 
        ? prev.filter(id => id !== reviewId)
        : [...prev, reviewId]
    );
  };

  const sortReviews = (reviews: Review[]) => {
    switch (sortBy) {
      case 'newest':
        return [...reviews].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      case 'helpful':
        return [...reviews].sort((a, b) => b.helpful - a.helpful);
      case 'highest':
        return [...reviews].sort((a, b) => b.rating - a.rating);
      case 'lowest':
        return [...reviews].sort((a, b) => a.rating - b.rating);
      default:
        return reviews;
    }
  };

  const sortedReviews = sortReviews(product.reviews);

  // Distribution of ratings
  const ratingCounts = Array(5).fill(0);
  product.reviews.forEach(review => {
    ratingCounts[5 - review.rating]++;
  });

  return (
    <div className="py-8 border-t border-gray-200">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Customer Reviews</h2>
      
      {/* Ratings summary */}
      <div className="flex flex-col md:flex-row gap-8 mb-8">
        <div className="w-full md:w-1/3">
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-5xl font-bold text-gray-900 mb-2">{product.avgRating.toFixed(1)}</div>
            <div className="flex justify-center mb-3">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i} 
                  className={cn(
                    "w-4 h-4",
                    i < Math.floor(product.avgRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                  )}
                />
              ))}
            </div>
            <div className="text-sm text-gray-500">{product.totalReviews} reviews</div>
          </div>
        </div>
        
        <div className="w-full md:w-2/3">
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map(rating => {
              const count = product.reviews.filter(r => r.rating === rating).length;
              const percentage = (count / product.reviews.length) * 100 || 0;
              
              return (
                <div key={rating} className="flex items-center">
                  <div className="flex items-center w-16">
                    <span className="text-sm text-gray-600">{rating} star</span>
                  </div>
                  <div className="flex-1 h-4 mx-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-yellow-500" 
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                  <div className="w-12 text-sm text-right text-gray-600">{percentage.toFixed(0)}%</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Sort options */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900">
          {product.reviews.length} Reviews
        </h3>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-700">Sort by:</span>
          <select 
            className="text-sm border border-gray-300 rounded-md p-1 bg-white"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
          >
            <option value="helpful">Most Helpful</option>
            <option value="newest">Newest</option>
            <option value="highest">Highest Rated</option>
            <option value="lowest">Lowest Rated</option>
          </select>
        </div>
      </div>
      
      {/* Review list */}
      <div className="space-y-6">
        {sortedReviews.map(review => {
          const isExpanded = expandedReviews.includes(review.id);
          const reviewDate = new Date(review.date).toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          });
          
          return (
            <div key={review.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-semibold text-gray-900">{review.user}</h4>
                  <div className="flex items-center mt-1">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={cn(
                            "w-4 h-4",
                            i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                          )}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-500">{reviewDate}</span>
                  </div>
                </div>
                <div className="text-sm text-gray-500 flex items-center">
                  <span className="mr-1">{review.helpful}</span> 
                  <span>found helpful</span>
                </div>
              </div>
              
              <h5 className="font-medium text-gray-900 mb-2">{review.title}</h5>
              
              <div className={cn(
                "text-gray-700 overflow-hidden transition-all duration-300",
                isExpanded ? "max-h-96" : "max-h-20"
              )}>
                <p>{review.comment}</p>
              </div>
              
              {review.comment.length > 100 && (
                <button 
                  className="text-sm font-medium text-ocean hover:underline mt-2"
                  onClick={() => toggleReviewExpansion(review.id)}
                >
                  {isExpanded ? "Show Less" : "Read More"}
                </button>
              )}
              
              <div className="mt-4 flex space-x-2">
                <Button variant="outline" size="sm" className="text-xs">
                  Helpful
                </Button>
                <Button variant="outline" size="sm" className="text-xs">
                  Report
                </Button>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Show more button */}
      {product.totalReviews > product.reviews.length && (
        <div className="mt-8 text-center">
          <Button variant="outline" className="border-ocean text-ocean hover:bg-ocean hover:text-white">
            Load More Reviews
          </Button>
        </div>
      )}
      
      {/* Write review CTA */}
      <div className="mt-10 bg-gray-50 rounded-lg p-6 text-center">
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Share Your Experience</h3>
        <p className="text-gray-700 mb-4">Tell others what you think about this product</p>
        <Button className="bg-ocean hover:bg-ocean-dark text-white">
          Write a Review
        </Button>
      </div>
    </div>
  );
}
