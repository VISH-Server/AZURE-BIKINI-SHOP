
import { useState } from 'react';
import { Product, ProductSize, ProductVariant } from '@/data/products';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingBag, Star, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProductDetailsProps {
  product: Product;
  activeVariant: ProductVariant;
  onVariantChange: (variant: ProductVariant) => void;
}

export function ProductDetails({ product, activeVariant, onVariantChange }: ProductDetailsProps) {
  const [selectedSize, setSelectedSize] = useState<ProductSize | null>(
    product.sizes.find(size => size.inStock) || null
  );
  const [quantity, setQuantity] = useState(1);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isShippingOpen, setIsShippingOpen] = useState(false);

  const handleSizeChange = (size: ProductSize) => {
    if (size.inStock) {
      setSelectedSize(size);
    }
  };

  const handleVariantChange = (variant: ProductVariant) => {
    onVariantChange(variant);
  };

  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  const formatPrice = (price: number) => {
    return `₹${price.toLocaleString('en-IN')}`;
  };

  return (
    <div className="w-full lg:w-1/2 p-1 lg:p-6">
      {/* Product Title and Badges */}
      <div className="mb-4">
        {product.tags.includes('sale') && (
          <Badge className="mb-2 bg-coral text-white">SALE</Badge>
        )}
        {product.tags.includes('new') && (
          <Badge className="mb-2 ml-2 bg-ocean text-white">NEW</Badge>
        )}
        <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
        
        {/* Rating */}
        <div className="flex items-center mt-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={cn(
                  "w-4 h-4",
                  i < Math.floor(product.avgRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                )}
              />
            ))}
          </div>
          <span className="ml-2 text-sm text-gray-500">
            {product.avgRating} ({product.totalReviews} reviews)
          </span>
        </div>
      </div>

      {/* Price */}
      <div className="mb-6">
        {product.salePrice ? (
          <div className="flex items-center">
            <span className="text-2xl font-bold text-gray-900">{formatPrice(product.salePrice)}</span>
            <span className="ml-2 text-lg text-gray-500 line-through">{formatPrice(product.price)}</span>
            <span className="ml-2 text-sm font-medium text-coral">
              Save {formatPrice(product.price - product.salePrice)}
            </span>
          </div>
        ) : (
          <span className="text-2xl font-bold text-gray-900">{formatPrice(product.price)}</span>
        )}
      </div>

      {/* Product Description */}
      <div className="mb-6">
        <p className="text-gray-700">{product.description}</p>
      </div>

      {/* Color Selection */}
      <div className="mb-6">
        <h2 className="text-sm font-medium text-gray-900 mb-2">Color: {activeVariant.color}</h2>
        <div className="flex space-x-2">
          {product.variants.map((variant, index) => (
            <button
              key={index}
              onClick={() => handleVariantChange(variant)}
              className={cn(
                "w-10 h-10 rounded-full border-2",
                variant.color === activeVariant.color ? "border-ocean ring-2 ring-ocean-light" : "border-gray-300"
              )}
              style={{ backgroundColor: variant.colorCode }}
              aria-label={variant.color}
            ></button>
          ))}
        </div>
      </div>

      {/* Size Selection */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-sm font-medium text-gray-900">Size: {selectedSize?.name || 'Select Size'}</h2>
          <button className="text-sm font-medium text-ocean hover:underline">Size Guide</button>
        </div>
        <div className="grid grid-cols-5 gap-2">
          {product.sizes.map((size) => (
            <button
              key={size.value}
              onClick={() => handleSizeChange(size)}
              disabled={!size.inStock}
              className={cn(
                "py-2 text-center border rounded-md text-sm font-medium transition-colors",
                selectedSize?.value === size.value 
                  ? "border-ocean bg-ocean text-white" 
                  : size.inStock 
                    ? "border-gray-300 hover:border-ocean text-gray-900" 
                    : "border-gray-200 bg-gray-100 text-gray-400 cursor-not-allowed"
              )}
            >
              {size.name}
              {!size.inStock && <span className="block text-xs">Out of stock</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Quantity */}
      <div className="mb-6">
        <h2 className="text-sm font-medium text-gray-900 mb-2">Quantity</h2>
        <div className="flex items-center border border-gray-300 rounded-md w-32">
          <button
            onClick={decrementQuantity}
            className="w-10 h-10 flex items-center justify-center text-gray-600 hover:text-ocean"
            disabled={quantity === 1}
          >
            <ChevronDown className="w-5 h-5" />
          </button>
          <div className="flex-1 text-center">
            <input
              type="text"
              value={quantity}
              readOnly
              className="w-full text-center border-none focus:outline-none text-gray-900"
            />
          </div>
          <button
            onClick={incrementQuantity}
            className="w-10 h-10 flex items-center justify-center text-gray-600 hover:text-ocean"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4 mb-8">
        <Button 
          className="flex-1 bg-ocean hover:bg-ocean-dark text-white"
          size="lg"
          disabled={!selectedSize}
        >
          <ShoppingBag className="w-5 h-5 mr-2" />
          Add to Bag
        </Button>
        <Button variant="outline" size="lg" className="border-gray-300">
          <Heart className="w-5 h-5" />
        </Button>
      </div>

      {/* Product Details Accordion */}
      <div className="border-t border-gray-200 pt-4">
        <button
          className="flex justify-between items-center w-full py-3 text-left"
          onClick={() => setIsDetailsOpen(!isDetailsOpen)}
        >
          <span className="text-base font-medium text-gray-900">Product Details</span>
          {isDetailsOpen ? (
            <ChevronUp className="w-5 h-5 text-gray-500" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-500" />
          )}
        </button>
        {isDetailsOpen && (
          <div className="pb-4">
            <ul className="list-disc pl-5 text-gray-700 space-y-1">
              {product.details.map((detail, index) => (
                <li key={index}>{detail}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Shipping & Returns Accordion */}
      <div className="border-t border-gray-200 pt-4">
        <button
          className="flex justify-between items-center w-full py-3 text-left"
          onClick={() => setIsShippingOpen(!isShippingOpen)}
        >
          <span className="text-base font-medium text-gray-900">Shipping & Returns</span>
          {isShippingOpen ? (
            <ChevronUp className="w-5 h-5 text-gray-500" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-500" />
          )}
        </button>
        {isShippingOpen && (
          <div className="pb-4 text-gray-700">
            <p className="mb-2"><strong>Free standard shipping</strong> on orders over ₹2999</p>
            <p className="mb-2"><strong>Standard delivery:</strong> 3-5 working days</p>
            <p className="mb-2"><strong>Express delivery:</strong> 1-2 working days</p>
            <p className="mt-4">Free returns within 30 days. See our <a href="#" className="text-ocean hover:underline">return policy</a> for more information.</p>
          </div>
        )}
      </div>
    </div>
  );
}
