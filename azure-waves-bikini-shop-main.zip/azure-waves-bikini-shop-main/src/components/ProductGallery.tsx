
import { useState } from 'react';
import { ProductVariant } from '@/data/products';
import { cn } from '@/lib/utils';

interface ProductGalleryProps {
  variants: ProductVariant[];
  activeVariant: ProductVariant;
}

export function ProductGallery({ variants, activeVariant }: ProductGalleryProps) {
  const [activeImage, setActiveImage] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPosition, setZoomPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isZoomed) return;
    
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    
    setZoomPosition({ x, y });
  };

  const handleMouseLeave = () => {
    setIsZoomed(false);
  };

  const toggleZoom = () => {
    setIsZoomed(!isZoomed);
  };

  return (
    <div className="w-full lg:w-1/2 space-y-4">
      {/* Main Image Display */}
      <div 
        className={cn(
          "relative w-full aspect-[3/4] overflow-hidden rounded-lg border border-gray-200 bg-white cursor-zoom-in",
          isZoomed && "cursor-zoom-out"
        )}
        onClick={toggleZoom}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        <div 
          className={cn(
            "w-full h-full transition-all duration-300 bg-white",
            isZoomed && "scale-150"
          )}
          style={isZoomed ? {
            transformOrigin: `${zoomPosition.x}% ${zoomPosition.y}%`
          } : {}}
        >
          <img 
            src={activeVariant.images[activeImage]} 
            alt="Product image" 
            className="w-full h-full object-cover object-center"
          />
        </div>
      </div>

      {/* Thumbnails */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {activeVariant.images.map((image, index) => (
          <button
            key={index}
            className={cn(
              "relative w-20 h-20 rounded-md overflow-hidden flex-shrink-0 border-2",
              activeImage === index ? "border-ocean" : "border-gray-200"
            )}
            onClick={() => setActiveImage(index)}
          >
            <img
              src={image}
              alt={`Product thumbnail ${index + 1}`}
              className="w-full h-full object-cover object-center"
            />
          </button>
        ))}
      </div>

      {/* Color Variants */}
      <div className="mt-4">
        <h3 className="text-sm font-medium text-gray-500 mb-2">Available Colors</h3>
        <div className="flex space-x-2">
          {variants.map((variant, index) => (
            <div 
              key={index}
              className={cn(
                "w-8 h-8 rounded-full cursor-pointer border-2",
                variant.color === activeVariant.color ? "border-ocean" : "border-transparent"
              )}
              style={{ backgroundColor: variant.colorCode }}
              aria-label={variant.color}
              role="button"
              tabIndex={0}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
