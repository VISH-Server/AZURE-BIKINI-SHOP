
import { Product } from '@/data/products';
import { Button } from '@/components/ui/button';
import { Star, ShoppingBag } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

interface RelatedProductsProps {
  products: Product[];
  title?: string;
}

export function RelatedProducts({ products, title = "You May Also Like" }: RelatedProductsProps) {
  const formatPrice = (price: number) => {
    return `₹${price.toLocaleString('en-IN')}`;
  };

  return (
    <div className="py-10 border-t border-gray-200">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">{title}</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {products.map(product => (
          <div key={product.id} className="group">
            <div className="relative mb-3 overflow-hidden rounded-lg bg-gray-100 aspect-[3/4]">
              <Link to={`/product/${product.id}`}>
                <img 
                  src={product.variants[0].images[0]} 
                  alt={product.name} 
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                />
              </Link>
              
              {product.salePrice && (
                <div className="absolute top-2 left-2 bg-coral text-white text-xs font-bold px-2 py-1 rounded">
                  SALE
                </div>
              )}
              
              <div className="absolute inset-x-0 bottom-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Button 
                  className="w-full rounded-none bg-ocean hover:bg-ocean-dark text-white flex items-center justify-center py-2"
                  size="sm"
                >
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  Quick Add
                </Button>
              </div>
            </div>
            
            <Link to={`/product/${product.id}`} className="block mb-1">
              <h3 className="text-sm font-medium text-gray-900 hover:text-ocean transition-colors line-clamp-1">
                {product.name}
              </h3>
            </Link>
            
            <div className="flex items-center mb-1">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i} 
                  className={cn(
                    "w-3 h-3",
                    i < Math.floor(product.avgRating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                  )}
                />
              ))}
              <span className="ml-1 text-xs text-gray-500">
                ({product.totalReviews})
              </span>
            </div>
            
            <div className="flex items-center">
              {product.salePrice ? (
                <>
                  <span className="font-medium text-coral">{formatPrice(product.salePrice)}</span>
                  <span className="ml-2 text-sm text-gray-500 line-through">{formatPrice(product.price)}</span>
                </>
              ) : (
                <span className="font-medium text-gray-900">{formatPrice(product.price)}</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
